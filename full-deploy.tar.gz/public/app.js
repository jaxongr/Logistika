// Telegram WebApp initialization
let tg = window.Telegram.WebApp;
let user = null;
let groups = [];
let selectedGroups = [];

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initTelegramWebApp();
    loadUserData();
    loadGroups();
    setupEventListeners();
    updateCharCount();
});

// Initialize Telegram WebApp
function initTelegramWebApp() {
    tg.ready();
    tg.expand();
    
    // Get user data from Telegram
    user = tg.initDataUnsafe?.user;
    
    if (user) {
        document.getElementById('userInfo').textContent = 
            `${user.first_name || ''} ${user.last_name || ''}`.trim() || user.username || 'User';
    }
    
    // Set main button
    tg.MainButton.setText('Send Messages');
    tg.MainButton.hide();
    
    tg.MainButton.onClick(function() {
        sendMessages();
    });
}

// Load user data
async function loadUserData() {
    try {
        // In real implementation, fetch from backend
        const userData = {
            freeMessagesUsed: 5,
            freeMessagesLimit: 10,
            hasActiveSubscription: false,
            subscriptionEndDate: null
        };
        
        updateSubscriptionStatus(userData);
    } catch (error) {
        console.error('Error loading user data:', error);
    }
}

// Load groups
async function loadGroups() {
    const groupsList = document.getElementById('groupsList');
    
    try {
        // In real implementation, fetch from backend
        groups = [
            {
                id: 1,
                telegramId: '-1001234567890',
                title: 'IT Developers Uzbekistan',
                username: 'it_dev_uz',
                memberCount: 15420,
                isActive: true,
                canSendMessage: true,
                lastMessageAt: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
            },
            {
                id: 2,
                telegramId: '-1001234567891',
                title: 'Marketing Group',
                username: null,
                memberCount: 8340,
                isActive: true,
                canSendMessage: false,
                lastMessageAt: new Date(Date.now() - 30 * 60 * 1000) // 30 minutes ago
            },
            {
                id: 3,
                telegramId: '-1001234567892',
                title: 'Business Network',
                username: 'business_network_uz',
                memberCount: 3210,
                isActive: true,
                canSendMessage: true,
                lastMessageAt: new Date(Date.now() - 5 * 60 * 60 * 1000) // 5 hours ago
            }
        ];
        
        renderGroups();
    } catch (error) {
        console.error('Error loading groups:', error);
        groupsList.innerHTML = '<div class="loading">Failed to load groups</div>';
    }
}

// Render groups list
function renderGroups() {
    const groupsList = document.getElementById('groupsList');
    
    if (groups.length === 0) {
        groupsList.innerHTML = `
            <div class="text-center">
                <p>No groups found</p>
                <p style="font-size: 14px; opacity: 0.7; margin-top: 10px;">
                    Add the bot to your groups to start posting messages
                </p>
            </div>
        `;
        return;
    }
    
    groupsList.innerHTML = groups.map(group => {
        const cooldownMinutes = group.canSendMessage ? 0 : 60;
        const statusClass = group.canSendMessage ? 'ready' : 'cooldown';
        const statusText = group.canSendMessage ? 'Ready' : `Cooldown ${cooldownMinutes}m`;
        
        return `
            <div class="group-item" onclick="toggleGroup(${group.id})">
                <input type="checkbox" id="group-${group.id}" ${selectedGroups.includes(group.id) ? 'checked' : ''}>
                <div class="group-info">
                    <div class="group-title">${group.title}</div>
                    <div class="group-details">
                        ${group.username ? '@' + group.username + ' • ' : ''}${group.memberCount?.toLocaleString() || 0} members
                    </div>
                </div>
                <div class="group-status ${statusClass}">${statusText}</div>
            </div>
        `;
    }).join('');
    
    updateSelectedCount();
}

// Setup event listeners
function setupEventListeners() {
    // Message text change
    document.getElementById('messageText').addEventListener('input', function() {
        updateCharCount();
        updatePreview();
        validateForm();
    });
    
    // Schedule type change
    document.querySelectorAll('input[name="scheduleType"]').forEach(radio => {
        radio.addEventListener('change', function() {
            toggleScheduleOptions();
        });
    });
    
    // Media file change
    document.getElementById('mediaFile').addEventListener('change', function() {
        handleMediaUpload();
        validateForm();
    });
}

// Tab navigation
function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabName + '-tab').classList.add('active');
    
    // Add active class to clicked button
    event.target.classList.add('active');
}

// Toggle message type media upload
function toggleMediaUpload() {
    const messageType = document.getElementById('messageType').value;
    const mediaUpload = document.getElementById('mediaUpload');
    
    if (messageType === 'text') {
        mediaUpload.style.display = 'none';
    } else {
        mediaUpload.style.display = 'block';
        
        // Update file accept attribute based on type
        const mediaFile = document.getElementById('mediaFile');
        switch (messageType) {
            case 'photo':
                mediaFile.accept = 'image/*';
                break;
            case 'video':
                mediaFile.accept = 'video/*';
                break;
            case 'document':
                mediaFile.accept = '*/*';
                break;
        }
    }
    
    validateForm();
}

// Handle media upload
function handleMediaUpload() {
    const file = document.getElementById('mediaFile').files[0];
    const preview = document.getElementById('mediaPreview');
    
    if (!file) {
        preview.innerHTML = '';
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const fileType = file.type;
        let previewElement;
        
        if (fileType.startsWith('image/')) {
            previewElement = `<img src="${e.target.result}" alt="Preview">`;
        } else if (fileType.startsWith('video/')) {
            previewElement = `<video controls src="${e.target.result}"></video>`;
        } else {
            previewElement = `<div class="file-preview">📄 ${file.name} (${formatFileSize(file.size)})</div>`;
        }
        
        preview.innerHTML = previewElement;
    };
    
    reader.readAsDataURL(file);
}

// Format text
function formatText(type) {
    const textarea = document.getElementById('messageText');
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);
    
    let formattedText = selectedText;
    
    switch (type) {
        case 'bold':
            formattedText = `<b>${selectedText}</b>`;
            break;
        case 'italic':
            formattedText = `<i>${selectedText}</i>`;
            break;
        case 'underline':
            formattedText = `<u>${selectedText}</u>`;
            break;
        case 'code':
            formattedText = `<code>${selectedText}</code>`;
            break;
    }
    
    textarea.value = textarea.value.substring(0, start) + formattedText + textarea.value.substring(end);
    textarea.focus();
    textarea.setSelectionRange(start + formattedText.length, start + formattedText.length);
    
    updateCharCount();
    updatePreview();
}

// Insert emoji
function insertEmoji() {
    const emojis = ['😀', '😂', '❤️', '👍', '🔥', '💯', '🎉', '👏', '🚀', '💪', '🌟', '✨'];
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
    
    const textarea = document.getElementById('messageText');
    const cursorPosition = textarea.selectionStart;
    
    textarea.value = textarea.value.substring(0, cursorPosition) + randomEmoji + textarea.value.substring(cursorPosition);
    textarea.focus();
    textarea.setSelectionRange(cursorPosition + randomEmoji.length, cursorPosition + randomEmoji.length);
    
    updateCharCount();
    updatePreview();
}

// Update character count
function updateCharCount() {
    const textarea = document.getElementById('messageText');
    const charCount = document.getElementById('charCount');
    
    charCount.textContent = textarea.value.length;
    
    if (textarea.value.length > 4096) {
        charCount.style.color = 'red';
    } else {
        charCount.style.color = '';
    }
}

// Update preview
function updatePreview() {
    const messageText = document.getElementById('messageText').value;
    const previewContent = document.getElementById('previewContent');
    
    if (!messageText.trim()) {
        previewContent.innerHTML = '<em>Preview will appear here...</em>';
        return;
    }
    
    // Simple HTML formatting preview
    const formattedText = messageText
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/&lt;b&gt;(.*?)&lt;\/b&gt;/g, '<b>$1</b>')
        .replace(/&lt;i&gt;(.*?)&lt;\/i&gt;/g, '<i>$1</i>')
        .replace(/&lt;u&gt;(.*?)&lt;\/u&gt;/g, '<u>$1</u>')
        .replace(/&lt;code&gt;(.*?)&lt;\/code&gt;/g, '<code>$1</code>')
        .replace(/\n/g, '<br>');
    
    previewContent.innerHTML = formattedText;
}

// Toggle group selection
function toggleGroup(groupId) {
    const checkbox = document.getElementById(`group-${groupId}`);
    checkbox.checked = !checkbox.checked;
    
    if (checkbox.checked) {
        if (!selectedGroups.includes(groupId)) {
            selectedGroups.push(groupId);
        }
    } else {
        selectedGroups = selectedGroups.filter(id => id !== groupId);
    }
    
    updateSelectedCount();
    validateForm();
}

// Select all groups
function selectAllGroups() {
    selectedGroups = groups.map(group => group.id);
    groups.forEach(group => {
        document.getElementById(`group-${group.id}`).checked = true;
    });
    updateSelectedCount();
    validateForm();
}

// Deselect all groups
function deselectAllGroups() {
    selectedGroups = [];
    groups.forEach(group => {
        document.getElementById(`group-${group.id}`).checked = false;
    });
    updateSelectedCount();
    validateForm();
}

// Update selected count
function updateSelectedCount() {
    document.getElementById('selectedCount').textContent = selectedGroups.length;
}

// Toggle schedule options
function toggleScheduleOptions() {
    const scheduleType = document.querySelector('input[name="scheduleType"]:checked').value;
    const scheduleOptions = document.getElementById('scheduleOptions');
    
    if (scheduleType === 'scheduled') {
        scheduleOptions.style.display = 'block';
        
        // Set minimum date to now
        const now = new Date();
        now.setMinutes(now.getMinutes() + 5); // Minimum 5 minutes from now
        document.getElementById('scheduleDateTime').min = now.toISOString().slice(0, 16);
    } else {
        scheduleOptions.style.display = 'none';
    }
}

// Select plan
function selectPlan(planType) {
    document.getElementById('paymentInstructions').style.display = 'block';
    
    // Highlight selected plan
    document.querySelectorAll('.plan-card').forEach(card => {
        card.style.borderColor = '';
    });
    document.querySelector(`[data-type="${planType}"]`).style.borderColor = 'var(--tg-theme-button-color, #007aff)';
    
    // Show payment info for selected plan
    const prices = {
        day: '7,000',
        week: '20,000',
        month: '60,000'
    };
    
    tg.showAlert(`Selected ${planType} plan for ${prices[planType]} UZS`);
}

// Submit payment
function submitPayment() {
    const screenshot = document.getElementById('paymentScreenshot').files[0];
    
    if (!screenshot) {
        tg.showAlert('Please upload payment screenshot');
        return;
    }
    
    // In real implementation, upload to backend
    tg.showAlert('Payment submitted for review. You will be notified once approved.');
}

// Update subscription status
function updateSubscriptionStatus(userData) {
    const statusCard = document.getElementById('subscriptionStatus');
    
    if (userData.hasActiveSubscription) {
        statusCard.className = 'status-card active';
        statusCard.innerHTML = `
            <div>✅ <strong>Premium Active</strong></div>
            <div style="font-size: 14px; opacity: 0.8; margin-top: 5px;">
                Expires: ${new Date(userData.subscriptionEndDate).toLocaleDateString()}
            </div>
        `;
    } else {
        statusCard.className = 'status-card expired';
        statusCard.innerHTML = `
            <div>⏰ Free Plan</div>
            <div style="font-size: 14px; opacity: 0.8; margin-top: 5px;">
                ${userData.freeMessagesUsed}/${userData.freeMessagesLimit} free messages used
            </div>
        `;
    }
}

// Validate form
function validateForm() {
    const messageText = document.getElementById('messageText').value.trim();
    const messageType = document.getElementById('messageType').value;
    const mediaFile = document.getElementById('mediaFile').files[0];
    const hasSelectedGroups = selectedGroups.length > 0;
    
    let isValid = hasSelectedGroups && messageText.length > 0 && messageText.length <= 4096;
    
    // Check media requirement
    if (messageType !== 'text') {
        isValid = isValid && mediaFile;
    }
    
    // Update buttons
    const previewBtn = document.getElementById('previewBtn');
    const sendBtn = document.getElementById('sendBtn');
    
    previewBtn.disabled = !isValid;
    sendBtn.disabled = !isValid;
    
    if (isValid) {
        tg.MainButton.show();
    } else {
        tg.MainButton.hide();
    }
}

// Show final preview
function showFinalPreview() {
    const messageText = document.getElementById('messageText').value;
    const messageType = document.getElementById('messageType').value;
    const scheduleType = document.querySelector('input[name="scheduleType"]:checked').value;
    const scheduleDateTime = document.getElementById('scheduleDateTime').value;
    const randomDelay = document.getElementById('randomDelay').checked;
    
    const selectedGroupsData = groups.filter(g => selectedGroups.includes(g.id));
    
    let previewHTML = `
        <div class="preview-section">
            <h4>📝 Message</h4>
            <div class="preview-box">${messageText.replace(/\n/g, '<br>')}</div>
        </div>
        
        <div class="preview-section">
            <h4>📊 Type</h4>
            <p>${messageType.toUpperCase()}</p>
        </div>
        
        <div class="preview-section">
            <h4>👥 Groups (${selectedGroupsData.length})</h4>
            <ul style="margin: 10px 0; padding-left: 20px;">
                ${selectedGroupsData.map(g => `<li>${g.title}</li>`).join('')}
            </ul>
        </div>
        
        <div class="preview-section">
            <h4>⏰ Schedule</h4>
            <p>${scheduleType === 'immediate' ? 'Send Immediately' : `Scheduled for ${new Date(scheduleDateTime).toLocaleString()}`}</p>
        </div>
        
        <div class="preview-section">
            <h4>🛡️ Anti-Spam</h4>
            <p>Random delay: ${randomDelay ? 'Enabled (8-20s)' : 'Disabled'}</p>
        </div>
    `;
    
    document.getElementById('finalPreview').innerHTML = previewHTML;
    document.getElementById('previewModal').style.display = 'block';
}

// Close modal
function closeModal() {
    document.getElementById('previewModal').style.display = 'none';
}

// Confirm and send
function confirmSend() {
    closeModal();
    sendMessages();
}

// Send messages
async function sendMessages() {
    const messageText = document.getElementById('messageText').value;
    const messageType = document.getElementById('messageType').value;
    const scheduleType = document.querySelector('input[name="scheduleType"]:checked').value;
    const scheduleDateTime = document.getElementById('scheduleDateTime').value;
    const randomDelay = document.getElementById('randomDelay').checked;
    const dailyLimit = document.getElementById('dailyLimit').value;
    const groupCooldown = document.getElementById('groupCooldown').value;
    
    const campaignData = {
        messageText,
        messageType,
        mediaFile: document.getElementById('mediaFile').files[0],
        targetGroups: selectedGroups,
        scheduleType,
        scheduledAt: scheduleType === 'scheduled' ? new Date(scheduleDateTime) : null,
        randomDelay,
        dailyLimit: parseInt(dailyLimit),
        groupCooldownMinutes: parseInt(groupCooldown)
    };
    
    try {
        // Show loading
        tg.MainButton.setText('Sending...');
        tg.MainButton.showProgress();
        
        // In real implementation, send to backend
        await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate API call
        
        tg.showAlert('Messages queued successfully!', function() {
            // Reset form
            document.getElementById('messageText').value = '';
            document.getElementById('mediaFile').value = '';
            document.getElementById('mediaPreview').innerHTML = '';
            selectedGroups = [];
            renderGroups();
            updateCharCount();
            updatePreview();
            validateForm();
            
            // Go to first tab
            showTab('compose');
            document.querySelector('.tab-btn').click();
        });
        
    } catch (error) {
        console.error('Error sending messages:', error);
        tg.showAlert('Failed to send messages. Please try again.');
    } finally {
        tg.MainButton.setText('Send Messages');
        tg.MainButton.hideProgress();
    }
}

// Utility functions
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Close modal on outside click
window.onclick = function(event) {
    const modal = document.getElementById('previewModal');
    if (event.target === modal) {
        closeModal();
    }
}