import { Controller, Get, Res } from '@nestjs/common';
import { Response } from 'express';
import * as path from 'path';
import { AppService } from './app.service';
@Controller()
export class AppController {
  constructor(
    private readonly appService: AppService
  ) {}

  @Get()
  root(@Res() res: Response) {
    const filePath = path.join(process.cwd(), 'public', 'index.html');
    console.log('Attempting to serve file from:', filePath);
    return res.sendFile(filePath);
  }

  @Get('webapp')
  webapp(@Res() res: Response) {
    try {
      return res.sendFile(path.join(process.cwd(), 'public', 'webapp.html'));
    } catch (error) {
      console.log('Webapp HTML file not found');
      return res.json({ 
        message: 'Mini-App endpoint',
        bot_token: '8479156569:AAEm3WzUo1d3rITQ7dDVtiSMeMZOEZdxx3Q',
        status: 'ready'
      });
    }
  }

  @Get('driver')
  driverApp(@Res() res: Response) {
    try {
      return res.sendFile(path.join(process.cwd(), 'public', 'driver-webapp.html'));
    } catch (error) {
      console.log('Driver webapp HTML file not found');
      return res.json({ 
        message: 'Driver Mini-App endpoint',
        status: 'ready'
      });
    }
  }

  @Get('admin')
  adminPanel(@Res() res: Response) {
    try {
      return res.sendFile(path.join(process.cwd(), 'src', 'dashboard', 'dashboard.html'));
    } catch (error) {
      console.log('Admin dashboard HTML file not found');
      return res.json({
        message: 'Admin Dashboard endpoint',
        status: 'ready',
        features: [
          'Orders Management',
          'Driver Management',
          'Analytics & Reports',
          'Payment System',
          'Real-time Monitoring'
        ]
      });
    }
  }

  @Get('dashboard')
  dashboard(@Res() res: Response) {
    return res.sendFile(path.join(process.cwd(), 'src', 'dashboard', 'dashboard.html'));
  }

  @Get('dashboard/staff-link')
  dashboardStaffLink(@Res() res: Response) {
    return res.redirect('/dashboard/xodimlar');
  }

  @Get('dashboard/users')
  dashboardUsers(@Res() res: Response) {
    return res.sendFile(path.join(process.cwd(), 'src', 'dashboard', 'users.html'));
  }

  @Get('dashboard/staff')
  dashboardStaff(@Res() res: Response) {
    return res.sendFile(path.join(process.cwd(), 'src', 'dashboard', 'staff.html'));
  }

  @Get('dashboard/xodimlar')
  async dashboardXodimlar(@Res() res: Response) {
    // Get staff data from API
    const staffData = [
      {
        id: 'staff-001',
        fullName: 'Akmal Karimov',
        username: 'akmal_admin',
        email: 'akmal@logimaster.uz',
        phone: '+998901234567',
        role: 'super_admin',
        department: 'Management',
        status: 'active',
        notes: 'Tizim administratori',
        createdAt: '2024-01-01',
        lastLogin: '2024-01-15T10:30:00Z'
      },
      {
        id: 'staff-002',
        fullName: 'Dilnoza Umarova',
        username: 'dilnoza_ops',
        email: 'dilnoza@logimaster.uz',
        phone: '+998902345678',
        role: 'admin',
        department: 'Operations',
        status: 'active',
        notes: 'Operatsiya menejeri',
        createdAt: '2024-01-05',
        lastLogin: '2024-01-15T09:15:00Z'
      }
    ];

    // Generate HTML directly
    const staffListHtml = staffData.map(staff => `
      <tr style="border-bottom: 1px solid #e5e7eb;">
        <td style="padding: 1rem;">
          <div style="display: flex; align-items: center;">
            <div style="width: 2.5rem; height: 2.5rem; background: linear-gradient(135deg, #3b82f6, #8b5cf6); border-radius: 50%; color: white; display: flex; align-items: center; justify-content: center; margin-right: 0.75rem; font-weight: 600;">
              ${staff.fullName.split(' ').map(n => n[0]).join('')}
            </div>
            <div>
              <div style="font-weight: 600; color: #111827;">${staff.fullName}</div>
              <div style="color: #6b7280; font-size: 0.875rem;">@${staff.username}</div>
            </div>
          </div>
        </td>
        <td style="padding: 1rem; color: #6b7280;">${staff.email}</td>
        <td style="padding: 1rem;">
          <span style="padding: 0.25rem 0.75rem; background: rgba(59, 130, 246, 0.1); color: #1e40af; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">${staff.role.toUpperCase()}</span>
        </td>
        <td style="padding: 1rem; color: #6b7280;">${staff.department}</td>
        <td style="padding: 1rem;">
          <span style="padding: 0.25rem 0.75rem; background: rgba(16, 185, 129, 0.1); color: #059669; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">FAOL</span>
        </td>
        <td style="padding: 1rem;">
          <div style="display: flex; gap: 0.5rem;">
            <button style="padding: 0.5rem; background: rgba(59, 130, 246, 0.1); color: #1e40af; border: none; border-radius: 0.375rem; cursor: pointer;">✏️</button>
            <button style="padding: 0.5rem; background: rgba(239, 68, 68, 0.1); color: #dc2626; border: none; border-radius: 0.375rem; cursor: pointer;">🗑️</button>
          </div>
        </td>
      </tr>
    `).join('');

    const html = `
    <!DOCTYPE html>
    <html lang="uz">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Xodimlar | LogiMaster Pro</title>
      <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f8fafc; }
        .container { max-width: 1200px; margin: 0 auto; padding: 2rem; }
        .header { background: white; padding: 1.5rem; border-radius: 1rem; margin-bottom: 2rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .header h1 { font-size: 2rem; font-weight: 700; color: #111827; margin-bottom: 0.5rem; }
        .header p { color: #6b7280; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
        .stat-card { background: white; padding: 1.5rem; border-radius: 1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .stat-number { font-size: 2rem; font-weight: 700; color: #111827; }
        .stat-label { color: #6b7280; margin-top: 0.5rem; }
        .actions { background: white; padding: 1.5rem; border-radius: 1rem; margin-bottom: 2rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .btn-primary { background: linear-gradient(135deg, #3b82f6, #8b5cf6); color: white; padding: 0.75rem 1.5rem; border: none; border-radius: 0.5rem; font-weight: 600; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 0.5rem; }
        .btn-primary:hover { opacity: 0.9; }
        .table-container { background: white; border-radius: 1rem; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .table-header { background: #f8fafc; padding: 1rem 1.5rem; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f8fafc; padding: 1rem; text-align: left; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb; }
        td { padding: 1rem; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1><i class="fas fa-users-cog" style="margin-right: 0.5rem; color: #3b82f6;"></i>Xodimlar</h1>
          <p>Platform xodimlari va role-based access control</p>
        </div>

        <div class="stats">
          <div class="stat-card">
            <div class="stat-number">${staffData.length}</div>
            <div class="stat-label">Jami xodimlar</div>
          </div>
          <div class="stat-card">
            <div class="stat-number">${staffData.filter(s => s.status === 'active').length}</div>
            <div class="stat-label">Faol xodimlar</div>
          </div>
          <div class="stat-card">
            <div class="stat-number">${staffData.filter(s => s.role === 'admin' || s.role === 'super_admin').length}</div>
            <div class="stat-label">Administratorlar</div>
          </div>
        </div>

        <div class="actions">
          <form method="GET" action="/dashboard/xodimlar/add" style="display: inline;">
            <button type="submit" class="btn-primary">
              <i class="fas fa-user-plus"></i>
              Yangi xodim qo'shish
            </button>
          </form>
        </div>

        <div class="table-container">
          <div class="table-header">
            Xodimlar ro'yxati
          </div>
          <table>
            <thead>
              <tr>
                <th>Xodim</th>
                <th>Email</th>
                <th>Rol</th>
                <th>Bo'lim</th>
                <th>Status</th>
                <th>Amallar</th>
              </tr>
            </thead>
            <tbody>
              ${staffListHtml}
            </tbody>
          </table>
        </div>
      </div>
    </body>
    </html>
    `;

    res.send(html);
  }

  @Get('dashboard/xodimlar/add')
  dashboardXodimlarAdd(@Res() res: Response) {
    const addStaffHtml = `
    <!DOCTYPE html>
    <html lang="uz">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Yangi xodim | LogiMaster Pro</title>
      <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f8fafc; }
        .container { max-width: 600px; margin: 0 auto; padding: 2rem; }
        .form-card { background: white; padding: 2rem; border-radius: 1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; margin-bottom: 0.5rem; font-weight: 600; color: #374151; }
        input, select, textarea { width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 0.5rem; font-size: 1rem; }
        input:focus, select:focus, textarea:focus { outline: none; border-color: #3b82f6; box-shadow: 0 0 0 1px #3b82f6; }
        .btn-primary { background: linear-gradient(135deg, #3b82f6, #8b5cf6); color: white; padding: 0.75rem 2rem; border: none; border-radius: 0.5rem; font-weight: 600; cursor: pointer; font-size: 1rem; }
        .btn-secondary { background: #6b7280; color: white; padding: 0.75rem 2rem; border: none; border-radius: 0.5rem; font-weight: 600; cursor: pointer; font-size: 1rem; margin-right: 1rem; }
        .form-help { font-size: 0.875rem; color: #6b7280; margin-top: 0.25rem; }
        .header { text-align: center; margin-bottom: 2rem; }
        .header h1 { font-size: 2rem; font-weight: 700; color: #111827; margin-bottom: 0.5rem; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1><i class="fas fa-user-plus" style="margin-right: 0.5rem; color: #3b82f6;"></i>Yangi xodim qo'shish</h1>
        </div>

        <div class="form-card">
          <form method="POST" action="/api/dashboard/staff">
            <div class="form-group">
              <label for="fullName">To'liq ism *</label>
              <input type="text" id="fullName" name="fullName" required>
            </div>

            <div class="form-group">
              <label for="username">Username *</label>
              <input type="text" id="username" name="username" required>
              <div class="form-help">Login uchun foydalaniladigan noyob nom</div>
            </div>

            <div class="form-group">
              <label for="password">Parol *</label>
              <input type="password" id="password" name="password" required>
              <div class="form-help">Kamida 6 ta belgi</div>
            </div>

            <div class="form-group">
              <label for="email">Email <span style="color: #9ca3af;">(ixtiyoriy)</span></label>
              <input type="email" id="email" name="email">
            </div>

            <div class="form-group">
              <label for="phone">Telefon</label>
              <input type="tel" id="phone" name="phone">
            </div>

            <div class="form-group">
              <label for="role">Rol *</label>
              <select id="role" name="role" required>
                <option value="">Rolni tanlang</option>
                <option value="admin">Administrator</option>
                <option value="moderator">Moderator</option>
                <option value="operator">Operator</option>
                <option value="analyst">Tahlilchi</option>
              </select>
            </div>

            <div class="form-group">
              <label for="department">Bo'lim</label>
              <input type="text" id="department" name="department" placeholder="Masalan: IT, Marketing, HR">
            </div>

            <div class="form-group">
              <label for="status">Status</label>
              <select id="status" name="status">
                <option value="active">Faol</option>
                <option value="inactive">Nofaol</option>
                <option value="suspended">To'xtatilgan</option>
              </select>
            </div>

            <div class="form-group">
              <label for="notes">Eslatma</label>
              <textarea id="notes" name="notes" rows="3" placeholder="Qo'shimcha ma'lumot..."></textarea>
            </div>

            <div style="display: flex; justify-content: space-between; margin-top: 2rem;">
              <a href="/dashboard/xodimlar" class="btn-secondary" style="text-decoration: none; display: inline-flex; align-items: center;">
                <i class="fas fa-arrow-left" style="margin-right: 0.5rem;"></i>
                Bekor qilish
              </a>
              <button type="submit" class="btn-primary">
                <i class="fas fa-save" style="margin-right: 0.5rem;"></i>
                Saqlash
              </button>
            </div>
          </form>
        </div>
      </div>
    </body>
    </html>
    `;

    res.send(addStaffHtml);
  }

  @Get('dashboard/map')
  dashboardMap(@Res() res: Response) {
    return res.sendFile(path.join(process.cwd(), 'src', 'dashboard', 'map.html'));
  }

  @Get('health')
  health() {
    return { status: 'OK', timestamp: new Date().toISOString() };
  }

  @Get('hello')
  getHello(): string {
    return this.appService.getHello();
  }
}