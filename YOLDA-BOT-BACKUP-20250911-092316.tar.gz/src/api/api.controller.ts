import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Param,
  Query,
  Headers,
  UnauthorizedException,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { BotService } from '../bot/bot.service';

@Controller('api')
export class ApiController {
  constructor(private readonly botService: BotService) {}

  // Driver Authentication
  @Post('driver/login')
  async loginDriver(@Body() body: { phone: string }) {
    const { phone } = body;
    
    if (!phone) {
      throw new BadRequestException('Phone number is required');
    }

    try {
      // Find driver by phone number
      const users = await this.botService.getAllUsers();
      const driver = users.find(user => 
        user.role === 'haydovchi' && 
        user.driverProfile?.phone === phone
      );

      if (!driver || !driver.driverProfile) {
        throw new NotFoundException('Driver not found with this phone number');
      }

      // Return driver data
      return {
        success: true,
        driver: {
          id: `driver_${driver.id}_${Date.now()}`,
          userId: driver.id,
          username: user.username || 'Unknown',
          driverName: driver.driverProfile.driverName,
          phone: driver.driverProfile.phone,
          truckType: driver.driverProfile.truckType,
          capacity: driver.driverProfile.capacity,
          rating: driver.driverProfile.rating || 5.0,
          completedOrders: driver.driverProfile.completedOrders || 0,
          status: 'offline',
        }
      };
    } catch (error) {
      console.error('Driver login error:', error);
      throw new BadRequestException('Login failed');
    }
  }

  @Post('driver/register')
  async registerDriver(@Body() driverData: {
    name: string;
    phone: string;
    tonnageMin: number;
    tonnageMax: number;
    price1: number;
    price2: number;
  }) {
    try {
      // This would integrate with the bot's driver registration process
      // For now, return success
      return {
        success: true,
        message: 'Driver registration initiated. Please complete via Telegram bot.',
      };
    } catch (error) {
      console.error('Driver registration error:', error);
      throw new BadRequestException('Registration failed');
    }
  }

  // Driver Status Management
  @Put('driver/:driverId/status')
  async updateDriverStatus(
    @Param('driverId') driverId: string,
    @Body() body: { status: 'available' | 'busy' | 'offline' }
  ) {
    try {
      // Update driver status in the bot service
      const userId = this.extractUserIdFromDriverId(driverId);
      await this.botService.updateDriverStatus(userId, body.status);
      
      return { success: true };
    } catch (error) {
      console.error('Update driver status error:', error);
      throw new BadRequestException('Failed to update status');
    }
  }

  @Put('driver/:driverId/location')
  async updateDriverLocation(
    @Param('driverId') driverId: string,
    @Body() location: { latitude: number; longitude: number }
  ) {
    try {
      const userId = this.extractUserIdFromDriverId(driverId);
      await this.botService.updateDriverLocation(userId, location);
      
      return { success: true };
    } catch (error) {
      console.error('Update driver location error:', error);
      throw new BadRequestException('Failed to update location');
    }
  }

  // Orders Management
  @Get('orders/available')
  async getAvailableOrders(@Headers('authorization') auth: string) {
    try {
      const driverId = this.extractDriverIdFromAuth(auth);
      const orders = await this.botService.getAvailableOrdersForMobileApp();
      
      return {
        success: true,
        data: orders,
      };
    } catch (error) {
      console.error('Get available orders error:', error);
      return { success: true, data: [] };
    }
  }

  @Post('orders/:orderId/accept')
  async acceptOrder(
    @Param('orderId') orderId: string,
    @Body() body: { driverId: string }
  ) {
    try {
      const userId = this.extractUserIdFromDriverId(body.driverId);
      await this.botService.acceptOrderFromMobileApp(orderId, userId);
      
      return { success: true };
    } catch (error) {
      console.error('Accept order error:', error);
      throw new BadRequestException('Failed to accept order');
    }
  }

  @Post('orders/:orderId/decline')
  async declineOrder(
    @Param('orderId') orderId: string,
    @Body() body: { driverId: string }
  ) {
    try {
      // Just log the decline for now
      console.log(`Driver ${body.driverId} declined order ${orderId}`);
      return { success: true };
    } catch (error) {
      console.error('Decline order error:', error);
      throw new BadRequestException('Failed to decline order');
    }
  }

  @Get('orders/:orderId')
  async getOrderDetails(@Param('orderId') orderId: string) {
    try {
      const order = await this.botService.getOrderDetails(orderId);
      if (!order) {
        throw new NotFoundException('Order not found');
      }
      
      return { success: true, data: order };
    } catch (error) {
      console.error('Get order details error:', error);
      throw new NotFoundException('Order not found');
    }
  }

  // Driver Profile & Stats
  @Get('driver/:driverId/profile')
  async getDriverProfile(@Param('driverId') driverId: string) {
    try {
      const userId = this.extractUserIdFromDriverId(driverId);
      const profile = await this.botService.getDriverProfile(userId);
      
      if (!profile) {
        throw new NotFoundException('Driver profile not found');
      }
      
      return { success: true, data: profile };
    } catch (error) {
      console.error('Get driver profile error:', error);
      throw new NotFoundException('Profile not found');
    }
  }

  @Get('driver/:driverId/earnings')
  async getDriverEarnings(@Param('driverId') driverId: string) {
    try {
      // For now, return sample data
      // In real implementation, this would fetch from database
      return {
        success: true,
        data: {
          today: 150000,
          week: 800000,
          month: 3200000,
        }
      };
    } catch (error) {
      console.error('Get driver earnings error:', error);
      return {
        success: true,
        data: { today: 0, week: 0, month: 0 }
      };
    }
  }

  @Get('driver/:driverId/orders')
  async getDriverOrderHistory(
    @Param('driverId') driverId: string,
    @Query('limit') limit: string = '20',
    @Query('offset') offset: string = '0'
  ) {
    try {
      const userId = this.extractUserIdFromDriverId(driverId);
      const orders = await this.botService.getDriverOrderHistory(
        userId, 
        parseInt(limit), 
        parseInt(offset)
      );
      
      return { success: true, data: orders };
    } catch (error) {
      console.error('Get driver order history error:', error);
      return { success: true, data: [] };
    }
  }

  // Route & Navigation
  @Post('route')
  async getRoute(@Body() body: {
    from: { latitude: number; longitude: number };
    to: { latitude: number; longitude: number };
  }) {
    try {
      // For now, return a simple route calculation
      // In real implementation, this would use Google Maps API or similar
      const distance = this.calculateDistance(
        body.from.latitude,
        body.from.longitude,
        body.to.latitude,
        body.to.longitude
      );
      
      return {
        success: true,
        data: {
          distance: Math.round(distance),
          duration: Math.round(distance / 1000 * 2), // Rough estimate: 2 minutes per km
          coordinates: [
            body.from,
            body.to, // In real implementation, this would be the actual route points
          ],
        }
      };
    } catch (error) {
      console.error('Route calculation error:', error);
      throw new BadRequestException('Route calculation failed');
    }
  }

  // Communication
  @Post('orders/:orderId/driver-contact')
  async notifyCustomerDriverContact(
    @Param('orderId') orderId: string,
    @Body() body: { driverId: string }
  ) {
    try {
      await this.botService.notifyCustomerDriverContact(orderId, body.driverId);
      return { success: true };
    } catch (error) {
      console.error('Driver contact notification error:', error);
      throw new BadRequestException('Notification failed');
    }
  }

  // Emergency & Support
  @Post('emergency')
  async reportEmergency(@Body() body: {
    driverId: string;
    orderId: string;
    message: string;
    location: { latitude: number; longitude: number };
  }) {
    try {
      // Log emergency and notify administrators
      console.log('EMERGENCY REPORTED:', body);
      await this.botService.handleEmergencyReport(body);
      
      return { success: true };
    } catch (error) {
      console.error('Emergency report error:', error);
      throw new BadRequestException('Emergency report failed');
    }
  }

  // App Configuration
  @Get('config')
  async getAppConfig() {
    return {
      success: true,
      data: {
        minAppVersion: '1.0.0',
        updateRequired: false,
        supportPhone: '+998901234567',
        emergencyPhone: '+998901234567',
      }
    };
  }

  // Helper methods
  private extractUserIdFromDriverId(driverId: string): number {
    // Extract user ID from driver ID format: driver_userId_timestamp
    const parts = driverId.split('_');
    if (parts.length >= 2) {
      return parseInt(parts[1]);
    }
    throw new BadRequestException('Invalid driver ID format');
  }

  private extractDriverIdFromAuth(auth: string): string {
    if (!auth || !auth.startsWith('Driver ')) {
      throw new UnauthorizedException('Invalid authorization header');
    }
    return auth.replace('Driver ', '');
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371000; // Earth's radius in meters
    const dLat = this.toRad(lat2 - lat1);
    const dLon = this.toRad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  private toRad(value: number): number {
    return value * Math.PI / 180;
  }
}